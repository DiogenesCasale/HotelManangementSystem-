<a <?php echo e($attributes->merge(["class" => "text-black dark:text-white py-2 px-4 hover:bg-neutral-200 dark:hover:bg-zinc-800 block rounded-md transition-colors duration-300"])); ?>> 
    <?php echo e($slot); ?>

</a><?php /**PATH /var/www/resources/views/components/sidebar/link.blade.php ENDPATH**/ ?>