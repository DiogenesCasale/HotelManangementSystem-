<template id="error-toast">
    <div
        class="bg-red-500 text-white px-3 py-2 rounded-lg shadow-xl flex gap-4 items-center transform transition-all duration-300 hover:scale-105 animate-fade-up">
        <?php if (isset($component)) { $__componentOriginala785ebda8bffccf74bb4ad01c006af88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala785ebda8bffccf74bb4ad01c006af88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.xmark-fill','data' => ['class' => 'text-2xl bg-red-400/50 rounded-md px-2.5 py-2 shadow-inner']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icons.xmark-fill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-2xl bg-red-400/50 rounded-md px-2.5 py-2 shadow-inner']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala785ebda8bffccf74bb4ad01c006af88)): ?>
<?php $attributes = $__attributesOriginala785ebda8bffccf74bb4ad01c006af88; ?>
<?php unset($__attributesOriginala785ebda8bffccf74bb4ad01c006af88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala785ebda8bffccf74bb4ad01c006af88)): ?>
<?php $component = $__componentOriginala785ebda8bffccf74bb4ad01c006af88; ?>
<?php unset($__componentOriginala785ebda8bffccf74bb4ad01c006af88); ?>
<?php endif; ?>

        <div class="flex flex-col">
            <p class="font-semibold" id="title"></p>

            <p class="tracking-wide text-sm" id="description"></p>
        </div>

        <button class="ml-auto transition-colors duration-200 hover:bg-red-400/50 px-2 py-0.5 rounded-md" id="close">
            <?php if (isset($component)) { $__componentOriginala785ebda8bffccf74bb4ad01c006af88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala785ebda8bffccf74bb4ad01c006af88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.xmark-fill','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icons.xmark-fill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala785ebda8bffccf74bb4ad01c006af88)): ?>
<?php $attributes = $__attributesOriginala785ebda8bffccf74bb4ad01c006af88; ?>
<?php unset($__attributesOriginala785ebda8bffccf74bb4ad01c006af88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala785ebda8bffccf74bb4ad01c006af88)): ?>
<?php $component = $__componentOriginala785ebda8bffccf74bb4ad01c006af88; ?>
<?php unset($__componentOriginala785ebda8bffccf74bb4ad01c006af88); ?>
<?php endif; ?>
        </button>
    </div>
</template>
<?php /**PATH /var/www/resources/views/components/toasts/error.blade.php ENDPATH**/ ?>