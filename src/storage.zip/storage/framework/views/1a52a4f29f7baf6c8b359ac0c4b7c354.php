<div <?php echo e($attributes->merge(['class' => 'flex flex-col gap-2 fixed  bottom-5 right-5 max-w-xl'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /var/www/resources/views/components/toasts/container.blade.php ENDPATH**/ ?>