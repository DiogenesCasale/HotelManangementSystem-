<label <?php echo e($attributes->merge(["class" => "text-base text-black dark:text-white text-sm"])); ?>>
    <?php echo e($slot); ?>

</label><?php /**PATH /var/www/resources/views/components/inputs/label.blade.php ENDPATH**/ ?>