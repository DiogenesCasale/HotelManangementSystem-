<i <?php echo e($attributes->merge(['class' => 'fa-solid fa-check'])); ?>></i>
<?php /**PATH /var/www/resources/views/components/icons/check-fill.blade.php ENDPATH**/ ?>