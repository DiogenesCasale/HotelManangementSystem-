<?php if (isset($component)) { $__componentOriginal1e62ea70552e2303ad88fc0b4cc5a488 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e62ea70552e2303ad88fc0b4cc5a488 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.link','data' => ['class' => 'hover:text-indigo-500','href' => ''.e(route('dashboard.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hover:text-indigo-500','href' => ''.e(route('dashboard.index')).'']); ?>
    <?php if (isset($component)) { $__componentOriginal6b68622c41c077a4e756f07bdecb50d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b68622c41c077a4e756f07bdecb50d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.home-fill','data' => ['class' => 'mr-2 transition-colors duration-150 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icons.home-fill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mr-2 transition-colors duration-150 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b68622c41c077a4e756f07bdecb50d9)): ?>
<?php $attributes = $__attributesOriginal6b68622c41c077a4e756f07bdecb50d9; ?>
<?php unset($__attributesOriginal6b68622c41c077a4e756f07bdecb50d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b68622c41c077a4e756f07bdecb50d9)): ?>
<?php $component = $__componentOriginal6b68622c41c077a4e756f07bdecb50d9; ?>
<?php unset($__componentOriginal6b68622c41c077a4e756f07bdecb50d9); ?>
<?php endif; ?>

    <span class="@max-[100px]/sidebar:hidden">
        Home
    </span>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e62ea70552e2303ad88fc0b4cc5a488)): ?>
<?php $attributes = $__attributesOriginal1e62ea70552e2303ad88fc0b4cc5a488; ?>
<?php unset($__attributesOriginal1e62ea70552e2303ad88fc0b4cc5a488); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e62ea70552e2303ad88fc0b4cc5a488)): ?>
<?php $component = $__componentOriginal1e62ea70552e2303ad88fc0b4cc5a488; ?>
<?php unset($__componentOriginal1e62ea70552e2303ad88fc0b4cc5a488); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal1e62ea70552e2303ad88fc0b4cc5a488 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e62ea70552e2303ad88fc0b4cc5a488 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.link','data' => ['class' => 'hover:text-indigo-500','href' => ''.e(route('dashboard.reservations.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hover:text-indigo-500','href' => ''.e(route('dashboard.reservations.index')).'']); ?>
    <?php if (isset($component)) { $__componentOriginal7ea0341619604dd42dd13ae49f4f681c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ea0341619604dd42dd13ae49f4f681c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.id-badge-fill','data' => ['class' => 'mr-2 transition-colors duration-150 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icons.id-badge-fill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mr-2 transition-colors duration-150 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ea0341619604dd42dd13ae49f4f681c)): ?>
<?php $attributes = $__attributesOriginal7ea0341619604dd42dd13ae49f4f681c; ?>
<?php unset($__attributesOriginal7ea0341619604dd42dd13ae49f4f681c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ea0341619604dd42dd13ae49f4f681c)): ?>
<?php $component = $__componentOriginal7ea0341619604dd42dd13ae49f4f681c; ?>
<?php unset($__componentOriginal7ea0341619604dd42dd13ae49f4f681c); ?>
<?php endif; ?>

    <span class="@max-[100px]/sidebar:hidden">
        Reservas
    </span>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e62ea70552e2303ad88fc0b4cc5a488)): ?>
<?php $attributes = $__attributesOriginal1e62ea70552e2303ad88fc0b4cc5a488; ?>
<?php unset($__attributesOriginal1e62ea70552e2303ad88fc0b4cc5a488); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e62ea70552e2303ad88fc0b4cc5a488)): ?>
<?php $component = $__componentOriginal1e62ea70552e2303ad88fc0b4cc5a488; ?>
<?php unset($__componentOriginal1e62ea70552e2303ad88fc0b4cc5a488); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/components/sidebar/receptionist/sidebar.blade.php ENDPATH**/ ?>