<i <?php echo e($attributes->merge([ "class" => "fa-solid fa-info-circle"])); ?>></i>
<?php /**PATH /var/www/resources/views/components/icons/info-circle-fill.blade.php ENDPATH**/ ?>