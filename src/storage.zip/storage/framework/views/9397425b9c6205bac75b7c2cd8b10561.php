<div class="text-sm">
    <?php
        $segments = request()->segments();
    ?>

    <ul class="flex">
        <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <p class="first-letter:uppercase dark:text-white text-black">
                    <?php echo e($segment); ?>

                </p>
            </li>

            <?php if($index < count($segments) - 1): ?>
                <span class="mx-1 text-indigo-500">></span>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH /var/www/resources/views/components/broadcrumb.blade.php ENDPATH**/ ?>