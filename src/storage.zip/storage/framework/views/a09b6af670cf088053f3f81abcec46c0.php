<div <?php echo e($attributes->merge(['class' => 'bg-white shadow-lg dark:bg-zinc-800 border dark:border-zinc-700 border-none rounded-lg shadow-md p-4'])); ?>>
    <div class="flex items-center gap-3">
        <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'icons.' . $icon] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-indigo-500/20 p-4 text-xl text-indigo-500 rounded-lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
        <h2 class="text-base text-black dark:text-white"><?php echo e($title ?? "Sem título"); ?></h2>
    </div>

    <div class="mt-4 flex">
        <p class="text-sm text-black dark:text-zinc-400"><?php echo e($legend ?? "Sem legenda"); ?></p>

        <span class="ml-auto font-bold text-sm text-black dark:text-white"><?php echo e($value ?? "0%"); ?></span>
    </div>

    <div class="w-full bg-neutral-300/50 dark:bg-zinc-700/50 rounded-full h-2 mt-1">
        <div class="bg-indigo-500 h-2 rounded-full" style="width: <?php echo e($porcent); ?>%;"></div>
    </div>
</div><?php /**PATH /var/www/resources/views/components/dashboard/card.blade.php ENDPATH**/ ?>