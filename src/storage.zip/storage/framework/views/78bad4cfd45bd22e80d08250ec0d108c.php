<nav class="@container/sidebar transition-all duration-700 bg-gray-50 dark:bg-zinc-900 border-r border-gray-300 dark:border-zinc-700 top-0 h-screen fixed py-4 px-2 w-64 flex flex-col gap-2"
    id="sidebar">
    <h1 class="font-bold text-4xl text-center textblack dark:text-white mb-4">LOGO</h1>

    <?php
        $type = 1;
    ?>

    <?php if($type === 1): ?>
        <?php if (isset($component)) { $__componentOriginal958b5c24966849d7094f2254148b215b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal958b5c24966849d7094f2254148b215b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.receptionist.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.receptionist.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal958b5c24966849d7094f2254148b215b)): ?>
<?php $attributes = $__attributesOriginal958b5c24966849d7094f2254148b215b; ?>
<?php unset($__attributesOriginal958b5c24966849d7094f2254148b215b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal958b5c24966849d7094f2254148b215b)): ?>
<?php $component = $__componentOriginal958b5c24966849d7094f2254148b215b; ?>
<?php unset($__componentOriginal958b5c24966849d7094f2254148b215b); ?>
<?php endif; ?>
    <?php elseif($type === 2): ?>
        <?php if (isset($component)) { $__componentOriginal954f8f97135828fb77339b01bdbf5d75 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal954f8f97135828fb77339b01bdbf5d75 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.housekeeper.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.housekeeper.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal954f8f97135828fb77339b01bdbf5d75)): ?>
<?php $attributes = $__attributesOriginal954f8f97135828fb77339b01bdbf5d75; ?>
<?php unset($__attributesOriginal954f8f97135828fb77339b01bdbf5d75); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal954f8f97135828fb77339b01bdbf5d75)): ?>
<?php $component = $__componentOriginal954f8f97135828fb77339b01bdbf5d75; ?>
<?php unset($__componentOriginal954f8f97135828fb77339b01bdbf5d75); ?>
<?php endif; ?>
    <?php elseif($type === 3): ?>
        <?php if (isset($component)) { $__componentOriginalba751d38f981fa832d24c08a43156c90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba751d38f981fa832d24c08a43156c90 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.manager.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.manager.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba751d38f981fa832d24c08a43156c90)): ?>
<?php $attributes = $__attributesOriginalba751d38f981fa832d24c08a43156c90; ?>
<?php unset($__attributesOriginalba751d38f981fa832d24c08a43156c90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba751d38f981fa832d24c08a43156c90)): ?>
<?php $component = $__componentOriginalba751d38f981fa832d24c08a43156c90; ?>
<?php unset($__componentOriginalba751d38f981fa832d24c08a43156c90); ?>
<?php endif; ?>
    <?php endif; ?>
</nav>
<?php /**PATH /var/www/resources/views/components/sidebar/sidebar.blade.php ENDPATH**/ ?>