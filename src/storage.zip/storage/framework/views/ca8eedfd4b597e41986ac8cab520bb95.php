<header class="transition-all duration-700 ml-64 bg-gray-50 border-b border-gray-300 dark:border-zinc-700 dark:bg-zinc-900 w-[calc(100%-16rem)] fixed top-0 p-4 flex justify-between items-center h-16" id="navbar">
    <button id="navbar-sidebar-button">
        <?php if (isset($component)) { $__componentOriginal615c550df2b1a7c483e03a307c171afb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal615c550df2b1a7c483e03a307c171afb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.bars-fill','data' => ['class' => 'text-2xl text-black dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icons.bars-fill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-2xl text-black dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal615c550df2b1a7c483e03a307c171afb)): ?>
<?php $attributes = $__attributesOriginal615c550df2b1a7c483e03a307c171afb; ?>
<?php unset($__attributesOriginal615c550df2b1a7c483e03a307c171afb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal615c550df2b1a7c483e03a307c171afb)): ?>
<?php $component = $__componentOriginal615c550df2b1a7c483e03a307c171afb; ?>
<?php unset($__componentOriginal615c550df2b1a7c483e03a307c171afb); ?>
<?php endif; ?>
    </button>

    <?php if (isset($component)) { $__componentOriginal0abc47c46b5c5fd3c900826958c2173c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0abc47c46b5c5fd3c900826958c2173c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar.notify','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar.notify'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0abc47c46b5c5fd3c900826958c2173c)): ?>
<?php $attributes = $__attributesOriginal0abc47c46b5c5fd3c900826958c2173c; ?>
<?php unset($__attributesOriginal0abc47c46b5c5fd3c900826958c2173c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0abc47c46b5c5fd3c900826958c2173c)): ?>
<?php $component = $__componentOriginal0abc47c46b5c5fd3c900826958c2173c; ?>
<?php unset($__componentOriginal0abc47c46b5c5fd3c900826958c2173c); ?>
<?php endif; ?>
</header>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/components/navbar/navbar.js'); ?><?php /**PATH /var/www/resources/views/components/navbar/navbar.blade.php ENDPATH**/ ?>