<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex h-screen">
        <div class="w-full p-5 flex flex-col items-center justify-center">
            <form class="w-full max-w-xl" id="login-form">
                <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginal4147a39065fbe9c6a7ec0c6b4c87b701 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4147a39065fbe9c6a7ec0c6b4c87b701 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.label','data' => ['for' => 'login']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'login']); ?>E-mail<span class="text-red-500">*</span> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4147a39065fbe9c6a7ec0c6b4c87b701)): ?>
<?php $attributes = $__attributesOriginal4147a39065fbe9c6a7ec0c6b4c87b701; ?>
<?php unset($__attributesOriginal4147a39065fbe9c6a7ec0c6b4c87b701); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4147a39065fbe9c6a7ec0c6b4c87b701)): ?>
<?php $component = $__componentOriginal4147a39065fbe9c6a7ec0c6b4c87b701; ?>
<?php unset($__componentOriginal4147a39065fbe9c6a7ec0c6b4c87b701); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0083b0a72a1c55e14006c38a7ad7c1e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0083b0a72a1c55e14006c38a7ad7c1e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input','data' => ['type' => 'text','name' => 'login','id' => 'login','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'login','id' => 'login','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0083b0a72a1c55e14006c38a7ad7c1e4)): ?>
<?php $attributes = $__attributesOriginal0083b0a72a1c55e14006c38a7ad7c1e4; ?>
<?php unset($__attributesOriginal0083b0a72a1c55e14006c38a7ad7c1e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0083b0a72a1c55e14006c38a7ad7c1e4)): ?>
<?php $component = $__componentOriginal0083b0a72a1c55e14006c38a7ad7c1e4; ?>
<?php unset($__componentOriginal0083b0a72a1c55e14006c38a7ad7c1e4); ?>
<?php endif; ?>
                <p class="text-red-500 text-sm" id="login-error"></p>

                <?php if (isset($component)) { $__componentOriginal4147a39065fbe9c6a7ec0c6b4c87b701 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4147a39065fbe9c6a7ec0c6b4c87b701 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.label','data' => ['for' => 'password','class' => 'mt-2 block']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password','class' => 'mt-2 block']); ?>Senha<span class="text-red-500">*</span> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4147a39065fbe9c6a7ec0c6b4c87b701)): ?>
<?php $attributes = $__attributesOriginal4147a39065fbe9c6a7ec0c6b4c87b701; ?>
<?php unset($__attributesOriginal4147a39065fbe9c6a7ec0c6b4c87b701); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4147a39065fbe9c6a7ec0c6b4c87b701)): ?>
<?php $component = $__componentOriginal4147a39065fbe9c6a7ec0c6b4c87b701; ?>
<?php unset($__componentOriginal4147a39065fbe9c6a7ec0c6b4c87b701); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0083b0a72a1c55e14006c38a7ad7c1e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0083b0a72a1c55e14006c38a7ad7c1e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.input','data' => ['type' => 'password','name' => 'password','id' => 'password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'password','name' => 'password','id' => 'password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0083b0a72a1c55e14006c38a7ad7c1e4)): ?>
<?php $attributes = $__attributesOriginal0083b0a72a1c55e14006c38a7ad7c1e4; ?>
<?php unset($__attributesOriginal0083b0a72a1c55e14006c38a7ad7c1e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0083b0a72a1c55e14006c38a7ad7c1e4)): ?>
<?php $component = $__componentOriginal0083b0a72a1c55e14006c38a7ad7c1e4; ?>
<?php unset($__componentOriginal0083b0a72a1c55e14006c38a7ad7c1e4); ?>
<?php endif; ?>
                <p class="text-red-500 text-sm" id="password-error"></p>

                <?php if (isset($component)) { $__componentOriginal2e09a98ac31583de6bbe1dbbcb84a639 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e09a98ac31583de6bbe1dbbcb84a639 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.indigo','data' => ['class' => 'w-full mt-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.indigo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full mt-4']); ?>Entrar <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e09a98ac31583de6bbe1dbbcb84a639)): ?>
<?php $attributes = $__attributesOriginal2e09a98ac31583de6bbe1dbbcb84a639; ?>
<?php unset($__attributesOriginal2e09a98ac31583de6bbe1dbbcb84a639); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e09a98ac31583de6bbe1dbbcb84a639)): ?>
<?php $component = $__componentOriginal2e09a98ac31583de6bbe1dbbcb84a639; ?>
<?php unset($__componentOriginal2e09a98ac31583de6bbe1dbbcb84a639); ?>
<?php endif; ?>
            </form>
        </div>

        <div
            class="hidden w-full bg-gradient-to-tr from-indigo-700 to-indigo-900 sm:flex flex-col items-center justify-center p-5">
            <h1
                class="text-white text-4xl font-bold tracking-wide animate-fade-down animate-ease-in-out animate-duration-1000">
                Bem-vindo novamente!
            </h1>
            <p
                class="text-white text-center text-pretty text-md mt-1 animate-fade-down animate-ease-in-out animate-duration-1000 animate-delay-200">
                Estamos felizes em tê-lo conosco! Nosso sistema foi desenvolvido para tornar o gerenciamento do seu hotel
                mais fácil e eficiente.
            </p>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal14c53be2aa9dff7a376b35ed809866a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14c53be2aa9dff7a376b35ed809866a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toasts.container','data' => ['id' => 'toast-container']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toasts.container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'toast-container']); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14c53be2aa9dff7a376b35ed809866a3)): ?>
<?php $attributes = $__attributesOriginal14c53be2aa9dff7a376b35ed809866a3; ?>
<?php unset($__attributesOriginal14c53be2aa9dff7a376b35ed809866a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14c53be2aa9dff7a376b35ed809866a3)): ?>
<?php $component = $__componentOriginal14c53be2aa9dff7a376b35ed809866a3; ?>
<?php unset($__componentOriginal14c53be2aa9dff7a376b35ed809866a3); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginale2a3eda698d9728ece82c0cd1d67620c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2a3eda698d9728ece82c0cd1d67620c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toasts.success','data' => ['title' => 'Sucesso','message' => 'Login realizado com sucesso!']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toasts.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Sucesso','message' => 'Login realizado com sucesso!']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2a3eda698d9728ece82c0cd1d67620c)): ?>
<?php $attributes = $__attributesOriginale2a3eda698d9728ece82c0cd1d67620c; ?>
<?php unset($__attributesOriginale2a3eda698d9728ece82c0cd1d67620c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2a3eda698d9728ece82c0cd1d67620c)): ?>
<?php $component = $__componentOriginale2a3eda698d9728ece82c0cd1d67620c; ?>
<?php unset($__componentOriginale2a3eda698d9728ece82c0cd1d67620c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2b8a2cc3359fed8aae87e6365920e9dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b8a2cc3359fed8aae87e6365920e9dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toasts.error','data' => ['message' => 'Login realizado com sucesso!']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toasts.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Login realizado com sucesso!']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b8a2cc3359fed8aae87e6365920e9dd)): ?>
<?php $attributes = $__attributesOriginal2b8a2cc3359fed8aae87e6365920e9dd; ?>
<?php unset($__attributesOriginal2b8a2cc3359fed8aae87e6365920e9dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b8a2cc3359fed8aae87e6365920e9dd)): ?>
<?php $component = $__componentOriginal2b8a2cc3359fed8aae87e6365920e9dd; ?>
<?php unset($__componentOriginal2b8a2cc3359fed8aae87e6365920e9dd); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9bd5ffb8f9af3d48f11ef545e5b5c96f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bd5ffb8f9af3d48f11ef545e5b5c96f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toasts.info','data' => ['message' => 'Login realizado com sucesso!']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toasts.info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Login realizado com sucesso!']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bd5ffb8f9af3d48f11ef545e5b5c96f)): ?>
<?php $attributes = $__attributesOriginal9bd5ffb8f9af3d48f11ef545e5b5c96f; ?>
<?php unset($__attributesOriginal9bd5ffb8f9af3d48f11ef545e5b5c96f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bd5ffb8f9af3d48f11ef545e5b5c96f)): ?>
<?php $component = $__componentOriginal9bd5ffb8f9af3d48f11ef545e5b5c96f; ?>
<?php unset($__componentOriginal9bd5ffb8f9af3d48f11ef545e5b5c96f); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/pages/login/login.js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/pages/login.blade.php ENDPATH**/ ?>