<button>
    <?php if (isset($component)) { $__componentOriginal971e2b8928ef00045711ff4a0f882b93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal971e2b8928ef00045711ff4a0f882b93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.bell-fill','data' => ['class' => 'text-2xl text-black dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icons.bell-fill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-2xl text-black dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal971e2b8928ef00045711ff4a0f882b93)): ?>
<?php $attributes = $__attributesOriginal971e2b8928ef00045711ff4a0f882b93; ?>
<?php unset($__attributesOriginal971e2b8928ef00045711ff4a0f882b93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal971e2b8928ef00045711ff4a0f882b93)): ?>
<?php $component = $__componentOriginal971e2b8928ef00045711ff4a0f882b93; ?>
<?php unset($__componentOriginal971e2b8928ef00045711ff4a0f882b93); ?>
<?php endif; ?>
</button><?php /**PATH /var/www/resources/views/components/navbar/notify.blade.php ENDPATH**/ ?>